export const stores = [
  {
    id: 'store-1',
    name: 'Urban Bowl Kitchen',
    cuisine: 'Healthy Bowls',
    eta: '20-30 min',
    rating: 4.8,
    address: '1201 Turner St, Lansing, MI',
    menu: [
      { id: 'ubk-1', name: 'Jerk Chicken Bowl', description: 'Rice, greens, plantains, jerk chicken', price: 14.5 },
      { id: 'ubk-2', name: 'Salmon Power Bowl', description: 'Roasted salmon, quinoa, avocado', price: 17.0 },
      { id: 'ubk-3', name: 'Tropical Lemonade', description: 'Pineapple, lemon, mint', price: 4.5 }
    ]
  },
  {
    id: 'store-2',
    name: 'Mitten Pizza Co.',
    cuisine: 'Pizza',
    eta: '25-35 min',
    rating: 4.6,
    address: '301 Michigan Ave, Lansing, MI',
    menu: [
      { id: 'mpc-1', name: 'Detroit Pepperoni', description: 'Crispy edge, brick cheese, pepperoni', price: 16.0 },
      { id: 'mpc-2', name: 'Veggie Supreme', description: 'Mushroom, peppers, onion, olives', price: 15.0 },
      { id: 'mpc-3', name: 'Garlic Bread', description: 'Toasted, buttery, cheesy', price: 6.0 }
    ]
  },
  {
    id: 'store-3',
    name: 'Capital Cafe',
    cuisine: 'Coffee & Breakfast',
    eta: '15-25 min',
    rating: 4.9,
    address: '88 Grand River Ave, East Lansing, MI',
    menu: [
      { id: 'cc-1', name: 'Iced Vanilla Latte', description: 'Double shot espresso and vanilla', price: 5.75 },
      { id: 'cc-2', name: 'Turkey Croissant', description: 'Turkey, cheddar, egg', price: 8.5 },
      { id: 'cc-3', name: 'Greek Yogurt Parfait', description: 'Granola, berries, honey', price: 6.25 }
    ]
  }
];

export const demoDrivers = [
  { id: 'drv-1', name: 'Maya', vehicle: 'Silver Honda Civic', status: 'available', lat: 42.7337, lng: -84.5555 },
  { id: 'drv-2', name: 'Jordan', vehicle: 'Black Toyota Corolla', status: 'available', lat: 42.7295, lng: -84.5522 },
  { id: 'drv-3', name: 'Chris', vehicle: 'Blue Nissan Sentra', status: 'available', lat: 42.7368, lng: -84.5489 }
];
