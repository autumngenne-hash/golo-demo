export class BaseProvider {
  constructor(key, name) {
    this.key = key;
    this.name = name;
  }

  async quote({ orderValue = 0 }) {
    const deliveryFee = Number((4.99 + orderValue * 0.04).toFixed(2));
    const serviceFee = Number((1.99 + orderValue * 0.02).toFixed(2));
    return {
      provider: this.key,
      providerName: this.name,
      deliveryFee,
      serviceFee,
      etaMinutes: 28,
      totalFees: Number((deliveryFee + serviceFee).toFixed(2))
    };
  }

  async createDelivery(order) {
    return {
      externalId: `${this.key}_${order.id}`,
      status: 'accepted'
    };
  }
}
