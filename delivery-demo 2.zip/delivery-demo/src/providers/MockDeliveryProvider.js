import { BaseProvider } from './BaseProvider.js';

export class MockDeliveryProvider extends BaseProvider {
  constructor() {
    super('mock', 'GOLO Mock Network');
  }

  async quote({ orderValue = 0 }) {
    const base = await super.quote({ orderValue });
    return {
      ...base,
      deliveryFee: 4.49,
      serviceFee: Number((1.49 + orderValue * 0.015).toFixed(2)),
      etaMinutes: 24,
      totalFees: Number((4.49 + 1.49 + orderValue * 0.015).toFixed(2))
    };
  }
}
