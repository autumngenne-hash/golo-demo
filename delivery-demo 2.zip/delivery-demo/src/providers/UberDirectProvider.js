import { BaseProvider } from './BaseProvider.js';

export class UberDirectProvider extends BaseProvider {
  constructor() {
    super('uber', 'Uber Direct-style Adapter');
  }

  async quote({ orderValue = 0 }) {
    return {
      provider: this.key,
      providerName: this.name,
      deliveryFee: Number((6.49 + orderValue * 0.025).toFixed(2)),
      serviceFee: 2.49,
      etaMinutes: 22,
      totalFees: Number((8.98 + orderValue * 0.025).toFixed(2))
    };
  }
}
