import { BaseProvider } from './BaseProvider.js';

export class DoorDashDriveProvider extends BaseProvider {
  constructor() {
    super('doordash', 'DoorDash-style Adapter');
  }

  async quote({ orderValue = 0 }) {
    return {
      provider: this.key,
      providerName: this.name,
      deliveryFee: Number((5.99 + orderValue * 0.03).toFixed(2)),
      serviceFee: 2.25,
      etaMinutes: 26,
      totalFees: Number((8.24 + orderValue * 0.03).toFixed(2))
    };
  }
}
