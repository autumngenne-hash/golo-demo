import { MockDeliveryProvider } from './providers/MockDeliveryProvider.js';
import { DoorDashDriveProvider } from './providers/DoorDashDriveProvider.js';
import { UberDirectProvider } from './providers/UberDirectProvider.js';

const providers = {
  mock: new MockDeliveryProvider(),
  doordash: new DoorDashDriveProvider(),
  uber: new UberDirectProvider()
};

export function getProvider(key = 'mock') {
  return providers[key] || providers.mock;
}

export function listProviders() {
  return Object.values(providers).map((provider) => ({
    key: provider.key,
    name: provider.name
  }));
}
