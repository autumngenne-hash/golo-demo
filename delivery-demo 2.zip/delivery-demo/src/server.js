import express from 'express';
import cors from 'cors';
import { v4 as uuidv4 } from 'uuid';
import { stores, demoDrivers } from './data.js';
import { getProvider, listProviders } from './providerRegistry.js';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const orders = [];
const STATUS_STEPS = ['accepted', 'preparing', 'ready_for_pickup', 'picked_up', 'on_the_way', 'delivered'];

function calculateSubtotal(items = []) {
  return Number(items.reduce((sum, item) => sum + Number(item.price) * Number(item.quantity || 1), 0).toFixed(2));
}

function getStoreSummary(store) {
  const { menu, ...summary } = store;
  return summary;
}

function assignDriver() {
  const driver = demoDrivers.find((d) => d.status === 'available') || demoDrivers[0];
  driver.status = 'assigned';
  return {
    id: driver.id,
    name: driver.name,
    vehicle: driver.vehicle,
    lat: driver.lat,
    lng: driver.lng
  };
}

function releaseDriver(driverId) {
  const driver = demoDrivers.find((d) => d.id === driverId);
  if (driver) driver.status = 'available';
}

function advanceOrder(order) {
  if (!order || ['delivered', 'cancelled'].includes(order.status)) return order;
  const currentIndex = STATUS_STEPS.indexOf(order.status);
  const nextIndex = Math.min(currentIndex + 1, STATUS_STEPS.length - 1);
  order.status = STATUS_STEPS[nextIndex];
  order.updatedAt = new Date().toISOString();
  if (order.driver) {
    order.driver.lat = Number((order.driver.lat + 0.0024).toFixed(6));
    order.driver.lng = Number((order.driver.lng + 0.0019).toFixed(6));
  }
  if (order.status === 'delivered' && order.driver) {
    releaseDriver(order.driver.id);
  }
  return order;
}

setInterval(() => {
  orders.forEach((order) => {
    if (['accepted', 'preparing', 'ready_for_pickup', 'picked_up', 'on_the_way'].includes(order.status)) {
      advanceOrder(order);
    }
  });
}, 15000);

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, app: 'GOLO Delivery Demo', providers: listProviders() });
});

app.get('/api/providers', (_req, res) => {
  res.json(listProviders());
});

app.get('/api/stores', (_req, res) => {
  res.json(stores.map(getStoreSummary));
});

app.get('/api/stores/:id/menu', (req, res) => {
  const store = stores.find((s) => s.id === req.params.id);
  if (!store) return res.status(404).json({ error: 'Store not found' });
  res.json(store);
});

app.post('/api/delivery/quote', async (req, res) => {
  const { provider = 'mock', orderValue = 0 } = req.body;
  const adapter = getProvider(provider);
  const quote = await adapter.quote({ orderValue });
  res.json({ ...quote, total: Number((Number(orderValue) + quote.totalFees).toFixed(2)) });
});

app.post('/api/orders', async (req, res) => {
  const { storeId, items = [], customerName = 'Autumn', customerAddress = '123 Demo St, Lansing, MI', provider = 'mock' } = req.body;
  const store = stores.find((s) => s.id === storeId);
  if (!store) return res.status(404).json({ error: 'Store not found' });
  if (!items.length) return res.status(400).json({ error: 'Cart is empty' });

  const normalizedItems = items.map((item) => ({ ...item, quantity: Number(item.quantity || 1) }));
  const subtotal = calculateSubtotal(normalizedItems);
  const adapter = getProvider(provider);
  const quote = await adapter.quote({ orderValue: subtotal, pickupAddress: store.address, dropoffAddress: customerAddress });
  const driver = assignDriver();

  const order = {
    id: uuidv4().slice(0, 8),
    externalDeliveryId: `${provider}_${uuidv4().slice(0, 8)}`,
    provider,
    providerName: adapter.name,
    storeId: store.id,
    storeName: store.name,
    storeAddress: store.address,
    customerName,
    customerAddress,
    items: normalizedItems,
    subtotal,
    fees: quote.totalFees,
    total: Number((subtotal + quote.totalFees).toFixed(2)),
    etaMinutes: quote.etaMinutes,
    status: 'accepted',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    driver
  };

  const delivery = await adapter.createDelivery(order);
  order.externalDeliveryId = delivery.externalId;
  order.status = delivery.status || order.status;

  orders.unshift(order);
  res.status(201).json(order);
});

app.get('/api/orders', (_req, res) => {
  res.json(orders);
});

app.get('/api/orders/:id', (req, res) => {
  const order = orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

app.patch('/api/orders/:id/status', (req, res) => {
  const order = orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  order.status = req.body.status || order.status;
  order.updatedAt = new Date().toISOString();
  res.json(order);
});

app.post('/api/orders/:id/advance', (req, res) => {
  const order = orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(advanceOrder(order));
});

app.post('/api/webhooks/delivery', (req, res) => {
  const { orderId, status, driverLat, driverLng } = req.body;
  const order = orders.find((o) => o.id === orderId);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (status) order.status = status;
  if (order.driver && typeof driverLat === 'number' && typeof driverLng === 'number') {
    order.driver.lat = driverLat;
    order.driver.lng = driverLng;
  }
  order.updatedAt = new Date().toISOString();
  res.json({ received: true, order });
});

app.get('/api/driver/jobs', (_req, res) => {
  res.json(
    orders
      .filter((o) => !['delivered', 'cancelled'].includes(o.status))
      .map((o) => ({
        orderId: o.id,
        storeName: o.storeName,
        customerAddress: o.customerAddress,
        status: o.status,
        providerName: o.providerName,
        driver: o.driver
      }))
  );
});

app.listen(PORT, () => {
  console.log(`GOLO Delivery Demo running at http://localhost:${PORT}`);
});
