# GOLO Delivery Demo

A branded demo delivery platform inspired by modern merchant-delivery flows.

## What is included
- Customer ordering UI with seeded merchants and cart checkout
- Merchant dashboard with order progression controls
- Driver dispatch panel with simulated courier movement
- Mock backend API built with Express
- Provider adapter layer for:
  - `mock` (GOLO mock network)
  - `doordash` (DoorDash-style adapter stub)
  - `uber` (Uber Direct-style adapter stub)

## Run locally
1. Open the project folder in Terminal
2. Install dependencies:
   npm install
3. Start the app:
   npm start
4. Visit:
   http://localhost:3000

## Main API routes
- `GET /api/providers`
- `GET /api/stores`
- `GET /api/stores/:id/menu`
- `POST /api/delivery/quote`
- `POST /api/orders`
- `GET /api/orders`
- `POST /api/orders/:id/advance`
- `GET /api/driver/jobs`
- `POST /api/webhooks/delivery`

## Good next upgrades
- Stripe test checkout
- Auth for customers, merchants, and drivers
- Real database (Supabase/Postgres)
- Real map SDK + live tracking
- Webhooks + real provider credentials
