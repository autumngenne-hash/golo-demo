let stores = [];
let cart = [];
let selectedProvider = 'mock';

async function fetchJSON(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function money(value) {
  return `$${Number(value || 0).toFixed(2)}`;
}

function cartSubtotal() {
  return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

function setQuoteMessage(html) {
  document.getElementById('quoteBox').innerHTML = html;
}

function renderStats(orders = []) {
  const active = orders.filter((order) => !['delivered', 'cancelled'].includes(order.status));
  const revenue = orders.reduce((sum, order) => sum + order.total, 0);
  document.getElementById('statsBar').innerHTML = `
    <div class="stat"><strong>${stores.length}</strong><span class="small">Seeded merchants</span></div>
    <div class="stat"><strong>${orders.length}</strong><span class="small">Orders placed</span></div>
    <div class="stat"><strong>${active.length}</strong><span class="small">Active deliveries</span></div>
    <div class="stat"><strong>${money(revenue)}</strong><span class="small">Demo GMV</span></div>
  `;
}

function addToCart(storeId, item) {
  const existing = cart.find((entry) => entry.id === item.id);
  if (existing) existing.quantity += 1;
  else cart.push({ ...item, storeId, quantity: 1 });
  renderCart();
}

function removeFromCart(itemId) {
  cart = cart.filter((item) => item.id !== itemId);
  renderCart();
}

function renderCart() {
  const wrapper = document.getElementById('cartItems');
  if (!cart.length) {
    wrapper.innerHTML = '<div class="muted">Your cart is empty. Add items from one merchant to create a demo order.</div>';
    return;
  }
  wrapper.innerHTML = cart.map((item) => `
    <div class="cart-line">
      <div>
        <strong>${item.name}</strong>
        <div class="small">Qty ${item.quantity} • ${money(item.price)} each</div>
      </div>
      <div>
        <div class="price">${money(item.price * item.quantity)}</div>
        <button class="secondary" data-remove="${item.id}">Remove</button>
      </div>
    </div>
  `).join('') + `
    <div class="cart-line">
      <div><strong>Subtotal</strong></div>
      <div class="price">${money(cartSubtotal())}</div>
    </div>
  `;

  wrapper.querySelectorAll('[data-remove]').forEach((button) => {
    button.addEventListener('click', () => removeFromCart(button.dataset.remove));
  });
}

async function loadProviders() {
  const providers = await fetchJSON('/api/providers');
  const select = document.getElementById('providerSelect');
  select.innerHTML = providers.map((provider) => `
    <option value="${provider.key}">${provider.name}</option>
  `).join('');
  selectedProvider = select.value;
  select.addEventListener('change', () => {
    selectedProvider = select.value;
  });
}

async function loadStores() {
  stores = await fetchJSON('/api/stores');
  const storeDetails = await Promise.all(stores.map((store) => fetchJSON(`/api/stores/${store.id}/menu`)));
  const wrapper = document.getElementById('stores');
  wrapper.innerHTML = storeDetails.map((store) => `
    <div class="store">
      <div class="store-header">
        <div>
          <h3>${store.name}</h3>
          <div class="small">${store.cuisine} • ${store.eta} • ⭐ ${store.rating}</div>
          <div class="small">${store.address}</div>
        </div>
        <span class="badge">Open for demo</span>
      </div>
      ${store.menu.map((item) => `
        <div class="menu-item">
          <div>
            <strong>${item.name}</strong>
            <div class="small">${item.description}</div>
          </div>
          <div>
            <div class="price">${money(item.price)}</div>
            <button data-add="${store.id}::${item.id}">Add to cart</button>
          </div>
        </div>
      `).join('')}
    </div>
  `).join('');

  wrapper.querySelectorAll('[data-add]').forEach((button) => {
    button.addEventListener('click', () => {
      const [storeId, itemId] = button.dataset.add.split('::');
      const store = storeDetails.find((entry) => entry.id === storeId);
      const item = store.menu.find((entry) => entry.id === itemId);
      const currentStoreIds = [...new Set(cart.map((entry) => entry.storeId))];
      if (currentStoreIds.length && !currentStoreIds.includes(storeId)) {
        alert('For this demo, keep one merchant per order. Clear the cart or continue with the same store.');
        return;
      }
      addToCart(storeId, item);
    });
  });
}

async function getQuote() {
  if (!cart.length) {
    setQuoteMessage('Add items first to calculate a delivery quote.');
    return;
  }
  const quote = await fetchJSON('/api/delivery/quote', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ provider: selectedProvider, orderValue: cartSubtotal() })
  });
  setQuoteMessage(`
    <div><strong>${quote.providerName}</strong></div>
    <div class="small">Delivery fee: ${money(quote.deliveryFee)}</div>
    <div class="small">Service fee: ${money(quote.serviceFee)}</div>
    <div class="small">ETA: ${quote.etaMinutes} min</div>
    <div style="margin-top:8px"><strong>Total est. ${money(quote.total)}</strong></div>
  `);
}

async function checkout() {
  try {
    if (!cart.length) throw new Error('Add at least one item first.');
    const customerName = document.getElementById('customerName').value || 'Autumn';
    const customerAddress = document.getElementById('address').value || '123 Demo St, Lansing, MI';
    const order = await fetchJSON('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        storeId: cart[0].storeId,
        items: cart.map(({ storeId, ...item }) => item),
        customerName,
        customerAddress,
        provider: selectedProvider
      })
    });
    cart = [];
    renderCart();
    setQuoteMessage(`<strong>Order ${order.id} placed.</strong><br><span class="small">${order.providerName} • ${order.status} • ETA ${order.etaMinutes} min</span>`);
    await loadOrders();
  } catch (error) {
    setQuoteMessage(`<span style="color:#ff9d9d">${error.message}</span>`);
  }
}

async function advanceOrder(orderId) {
  await fetchJSON(`/api/orders/${orderId}/advance`, { method: 'POST' });
  await loadOrders();
}

function renderMerchantOrders(orders) {
  const wrapper = document.getElementById('merchantOrders');
  if (!orders.length) {
    wrapper.innerHTML = '<div class="muted">No orders yet. Place one from the customer panel.</div>';
    return;
  }
  wrapper.innerHTML = orders.map((order) => `
    <div class="order-card">
      <div class="order-meta">
        <div><strong>Order ${order.id}</strong> • ${order.storeName}</div>
        <div class="small">${order.customerName} • ${order.customerAddress}</div>
        <div class="small">${order.items.map((item) => `${item.quantity}× ${item.name}`).join(', ')}</div>
        <div class="small">${order.providerName} • Total ${money(order.total)}</div>
        <div><span class="status">${order.status.replaceAll('_', ' ')}</span></div>
      </div>
      <div>
        <button class="secondary" data-advance="${order.id}">Advance</button>
      </div>
    </div>
  `).join('');
  wrapper.querySelectorAll('[data-advance]').forEach((button) => {
    button.addEventListener('click', () => advanceOrder(button.dataset.advance));
  });
}

function renderDriverJobs(orders) {
  const wrapper = document.getElementById('driverJobs');
  const jobs = orders.filter((order) => !['delivered', 'cancelled'].includes(order.status));
  if (!jobs.length) {
    wrapper.innerHTML = '<div class="muted">No active courier jobs.</div>';
    return;
  }
  wrapper.innerHTML = jobs.map((order) => `
    <div class="job-card">
      <div class="job-meta">
        <div><strong>${order.driver.name}</strong> • ${order.driver.vehicle}</div>
        <div class="small">Pickup: ${order.storeName}</div>
        <div class="small">Dropoff: ${order.customerAddress}</div>
        <div class="small">Location: ${order.driver.lat.toFixed(4)}, ${order.driver.lng.toFixed(4)}</div>
        <div><span class="status">${order.status.replaceAll('_', ' ')}</span></div>
      </div>
      <div class="small">${order.providerName}</div>
    </div>
  `).join('');
}

async function loadOrders() {
  const orders = await fetchJSON('/api/orders');
  renderStats(orders);
  renderMerchantOrders(orders);
  renderDriverJobs(orders);
}

async function init() {
  await loadProviders();
  await loadStores();
  renderCart();
  await loadOrders();
  document.getElementById('quoteBtn').addEventListener('click', getQuote);
  document.getElementById('checkoutBtn').addEventListener('click', checkout);
  document.getElementById('refreshBtn').addEventListener('click', loadOrders);
  setInterval(loadOrders, 10000);
}

init().catch((error) => {
  document.body.innerHTML = `<pre style="padding:24px;color:white">${error.message}</pre>`;
});
