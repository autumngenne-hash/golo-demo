const express = require('express');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const stores = [
  {
    id: '1',
    name: 'Rooted Grill',
    eta: '22-32 min',
    rating: 4.8,
    fee: 3.99,
    cuisine: 'Bowls • Salads • Wraps',
    menu: [
      { id: 'm1', name: 'Glow Bowl', price: 13.5, description: 'Chicken, rice, avocado, greens' },
      { id: 'm2', name: 'Turmeric Wrap', price: 11.0, description: 'Grilled chicken, slaw, aioli' },
      { id: 'm3', name: 'Sweet Heat Fries', price: 5.5, description: 'Crispy fries with sweet chili' }
    ]
  },
  {
    id: '2',
    name: 'Cozy Bites',
    eta: '18-28 min',
    rating: 4.7,
    fee: 2.99,
    cuisine: 'Comfort Food • Wings • Sides',
    menu: [
      { id: 'm4', name: 'Honey Pepper Wings', price: 14.0, description: '8-piece wings' },
      { id: 'm5', name: 'Loaded Mac', price: 9.5, description: 'Creamy mac with crispy topping' },
      { id: 'm6', name: 'Lemon Kale', price: 6.0, description: 'Sauteed kale with lemon butter' }
    ]
  }
];

let orders = [];
let nextOrderId = 1001;

const providerAdapters = {
  mock: {
    name: 'Mock Delivery Provider',
    quote: ({ items }) => ({
      provider: 'mock',
      deliveryFee: 4.99,
      serviceFee: +(items.reduce((s, i) => s + i.price * i.qty, 0) * 0.08).toFixed(2),
      etaMinutes: 28
    })
  },
  doordash: {
    name: 'DoorDash Drive Adapter Stub',
    quote: ({ items }) => ({
      provider: 'doordash',
      deliveryFee: 5.49,
      serviceFee: +(items.reduce((s, i) => s + i.price * i.qty, 0) * 0.09).toFixed(2),
      etaMinutes: 24,
      note: 'Stub adapter — swap in live credentials later.'
    })
  },
  uber: {
    name: 'Uber Direct Adapter Stub',
    quote: ({ items }) => ({
      provider: 'uber',
      deliveryFee: 5.79,
      serviceFee: +(items.reduce((s, i) => s + i.price * i.qty, 0) * 0.1).toFixed(2),
      etaMinutes: 21,
      note: 'Stub adapter — swap in live credentials later.'
    })
  }
};

const statusFlow = ['pending', 'accepted', 'preparing', 'ready_for_pickup', 'picked_up', 'on_the_way', 'delivered'];

app.get('/api/stores', (req, res) => {
  res.json(stores.map(({ menu, ...store }) => store));
});

app.get('/api/stores/:id/menu', (req, res) => {
  const store = stores.find(s => s.id === req.params.id);
  if (!store) return res.status(404).json({ error: 'Store not found' });
  res.json(store);
});

app.post('/api/delivery/quote', (req, res) => {
  const { items = [], provider = 'mock' } = req.body || {};
  const adapter = providerAdapters[provider] || providerAdapters.mock;
  const subtotal = +items.reduce((s, i) => s + i.price * i.qty, 0).toFixed(2);
  const quote = adapter.quote({ items });
  res.json({
    subtotal,
    ...quote,
    total: +(subtotal + quote.deliveryFee + quote.serviceFee).toFixed(2)
  });
});

app.post('/api/orders', (req, res) => {
  const { customerName, storeId, items = [], provider = 'mock', address = '123 Demo St' } = req.body || {};
  const store = stores.find(s => s.id === storeId);
  if (!store) return res.status(404).json({ error: 'Store not found' });
  const quote = (providerAdapters[provider] || providerAdapters.mock).quote({ items });
  const subtotal = +items.reduce((s, i) => s + i.price * i.qty, 0).toFixed(2);
  const order = {
    id: String(nextOrderId++),
    customerName: customerName || 'Demo Customer',
    storeId,
    storeName: store.name,
    address,
    items,
    provider,
    status: 'pending',
    subtotal,
    deliveryFee: quote.deliveryFee,
    serviceFee: quote.serviceFee,
    total: +(subtotal + quote.deliveryFee + quote.serviceFee).toFixed(2),
    createdAt: new Date().toISOString(),
    driverName: 'A. Carter',
    driverLocation: { lat: 42.7325, lng: -84.5555 }
  };
  orders.unshift(order);
  res.json(order);
});

app.get('/api/orders', (req, res) => {
  res.json(orders);
});

app.get('/api/orders/:id', (req, res) => {
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

app.patch('/api/orders/:id/status', (req, res) => {
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  const { status } = req.body || {};
  if (!statusFlow.includes(status)) return res.status(400).json({ error: 'Invalid status' });
  order.status = status;
  res.json(order);
});

app.post('/api/orders/:id/advance', (req, res) => {
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  const currentIndex = statusFlow.indexOf(order.status);
  if (currentIndex < statusFlow.length - 1) {
    order.status = statusFlow[currentIndex + 1];
    order.driverLocation.lat += 0.002;
    order.driverLocation.lng -= 0.003;
  }
  res.json(order);
});

app.get('/api/driver/jobs', (req, res) => {
  res.json(orders.filter(o => ['ready_for_pickup', 'picked_up', 'on_the_way'].includes(o.status)));
});

app.get('/api/providers', (req, res) => {
  res.json(Object.keys(providerAdapters).map(key => ({ key, name: providerAdapters[key].name })));
});

app.get('*', (_, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(port, () => {
  console.log(`Delivery demo running on http://localhost:${port}`);
});
